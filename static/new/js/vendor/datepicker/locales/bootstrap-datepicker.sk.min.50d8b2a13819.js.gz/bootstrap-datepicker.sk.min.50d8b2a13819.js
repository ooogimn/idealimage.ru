!(function (a) {
  a.fn.datepicker.dates.sk = {
    days: ['Nedeľa', 'Pondelok', 'Utorok', 'Streda', 'Štvrtok', 'Piatok', 'Sobota'],
    daysShort: ['Ned', 'Pon', 'Uto', 'Str', 'Štv', 'Pia', 'Sob'],
    daysMin: ['Ne', 'Po', 'Ut', 'St', 'Št', 'Pia', 'So'],
    months: ['Január', 'Február', 'Marec', 'Apríl', 'Máj', 'Jún', 'Júl', 'August', 'September', 'Október', 'November', 'December'],
    monthsShort: ['Jan', 'Feb', 'Mar', 'Apr', 'Máj', 'Jún', 'Júl', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
    today: 'Dnes',
    clear: 'Vymazať',
    weekStart: 1,
    format: 'd.m.yyyy',
  };
})(jQuery);
