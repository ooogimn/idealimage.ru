/*! jQuery Validation Plugin - v1.19.2 - 5/23/2020
 * https://jqueryvalidation.org/
 * Copyright (c) 2020 Jörn Zaefferer; Licensed MIT */
!(function (a) {
  'function' == typeof define && define.amd
    ? define(['jquery', '../jquery.validate.min'], a)
    : 'object' == typeof module && module.exports
    ? (module.exports = a(require('jquery')))
    : a(jQuery);
})(function (a) {
  return (
    a.extend(a.validator.messages, {
      required: 'Bu xana mütləq doldurulmalıdır.',
      remote: 'Zəhmət olmasa, düzgün məna daxil edin.',
      email: 'Zəhmət olmasa, düzgün elektron poçt daxil edin.',
      url: 'Zəhmət olmasa, düzgün URL daxil edin.',
      date: 'Zəhmət olmasa, düzgün tarix daxil edin.',
      dateISO: 'Zəhmət olmasa, düzgün ISO formatlı tarix daxil edin.',
      number: 'Zəhmət olmasa, düzgün rəqəm daxil edin.',
      digits: 'Zəhmət olmasa, yalnız rəqəm daxil edin.',
      creditcard: 'Zəhmət olmasa, düzgün kredit kart nömrəsini daxil edin.',
      equalTo: 'Zəhmət olmasa, eyni mənanı bir daha daxil edin.',
      extension: 'Zəhmət olmasa, düzgün genişlənməyə malik faylı seçin.',
      maxlength: a.validator.format('Zəhmət olmasa, {0} simvoldan çox olmayaraq daxil edin.'),
      minlength: a.validator.format('Zəhmət olmasa, {0} simvoldan az olmayaraq daxil edin.'),
      rangelength: a.validator.format('Zəhmət olmasa, {0} - {1} aralığında uzunluğa malik simvol daxil edin.'),
      range: a.validator.format('Zəhmət olmasa, {0} - {1} aralığında rəqəm daxil edin.'),
      max: a.validator.format('Zəhmət olmasa, {0} və ondan kiçik rəqəm daxil edin.'),
      min: a.validator.format('Zəhmət olmasa, {0} və ondan böyük rəqəm daxil edin'),
    }),
    a
  );
});
