/*! jQuery Validation Plugin - v1.19.2 - 5/23/2020
 * https://jqueryvalidation.org/
 * Copyright (c) 2020 Jörn Zaefferer; Licensed MIT */
!(function (a) {
  'function' == typeof define && define.amd
    ? define(['jquery', '../jquery.validate.min'], a)
    : 'object' == typeof module && module.exports
    ? (module.exports = a(require('jquery')))
    : a(jQuery);
})(function (a) {
  return (
    a.extend(a.validator.messages, {
      required: 'Este campo es obligatorio.',
      remote: 'Por favor, rellena este campo.',
      email: 'Por favor, escribe una dirección de correo válida.',
      url: 'Por favor, escribe una URL válida.',
      date: 'Por favor, escribe una fecha válida.',
      dateISO: 'Por favor, escribe una fecha (ISO) válida.',
      number: 'Por favor, escribe un número válido.',
      digits: 'Por favor, escribe sólo dígitos.',
      creditcard: 'Por favor, escribe un número de tarjeta válido.',
      equalTo: 'Por favor, escribe el mismo valor de nuevo.',
      extension: 'Por favor, escribe un valor con una extensión aceptada.',
      maxlength: a.validator.format('Por favor, no escribas más de {0} caracteres.'),
      minlength: a.validator.format('Por favor, no escribas menos de {0} caracteres.'),
      rangelength: a.validator.format('Por favor, escribe un valor entre {0} y {1} caracteres.'),
      range: a.validator.format('Por favor, escribe un valor entre {0} y {1}.'),
      max: a.validator.format('Por favor, escribe un valor menor o igual a {0}.'),
      min: a.validator.format('Por favor, escribe un valor mayor o igual a {0}.'),
      nifES: 'Por favor, escribe un NIF válido.',
      nieES: 'Por favor, escribe un NIE válido.',
      cifES: 'Por favor, escribe un CIF válido.',
    }),
    a
  );
});
