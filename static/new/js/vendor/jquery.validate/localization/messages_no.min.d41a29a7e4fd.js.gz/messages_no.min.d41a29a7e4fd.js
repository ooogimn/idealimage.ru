/*! jQuery Validation Plugin - v1.19.2 - 5/23/2020
 * https://jqueryvalidation.org/
 * Copyright (c) 2020 Jörn Zaefferer; Licensed MIT */
!(function (a) {
  'function' == typeof define && define.amd
    ? define(['jquery', '../jquery.validate.min'], a)
    : 'object' == typeof module && module.exports
    ? (module.exports = a(require('jquery')))
    : a(jQuery);
})(function (a) {
  return (
    a.extend(a.validator.messages, {
      required: 'Angi en verdi.',
      remote: 'Ugyldig verdi.',
      email: 'Angi en gyldig epostadresse.',
      url: 'Angi en gyldig URL.',
      date: 'Angi en gyldig dato.',
      dateISO: 'Angi en gyldig dato (&ARING;&ARING;&ARING;&ARING;-MM-DD).',
      number: 'Angi et gyldig tall.',
      digits: 'Skriv kun tall.',
      equalTo: 'Skriv samme verdi igjen.',
      maxlength: a.validator.format('Maksimalt {0} tegn.'),
      minlength: a.validator.format('Minimum {0} tegn.'),
      rangelength: a.validator.format('Angi minimum {0} og maksimum {1} tegn.'),
      range: a.validator.format('Angi en verdi mellom {0} og {1}.'),
      max: a.validator.format('Angi en verdi som er mindre eller lik {0}.'),
      min: a.validator.format('Angi en verdi som er st&oslash;rre eller lik {0}.'),
      step: a.validator.format('Angi en verdi ganger {0}.'),
      creditcard: 'Angi et gyldig kredittkortnummer.',
    }),
    a
  );
});
