/*! jQuery Validation Plugin - v1.19.2 - 5/23/2020
 * https://jqueryvalidation.org/
 * Copyright (c) 2020 Jörn Zaefferer; Licensed MIT */
!(function (a) {
  'function' == typeof define && define.amd
    ? define(['jquery', '../jquery.validate.min'], a)
    : 'object' == typeof module && module.exports
    ? (module.exports = a(require('jquery')))
    : a(jQuery);
})(function (a) {
  return (
    a.extend(a.validator.messages, {
      required: 'To pole jest wymagane.',
      remote: 'Proszę o wypełnienie tego pola.',
      email: 'Proszę o podanie prawidłowego adresu email.',
      url: 'Proszę o podanie prawidłowego URL.',
      date: 'Proszę o podanie prawidłowej daty.',
      dateISO: 'Proszę o podanie prawidłowej daty (ISO).',
      number: 'Proszę o podanie prawidłowej liczby.',
      digits: 'Proszę o podanie samych cyfr.',
      creditcard: 'Proszę o podanie prawidłowej karty kredytowej.',
      equalTo: 'Proszę o podanie tej samej wartości ponownie.',
      extension: 'Proszę o podanie wartości z prawidłowym rozszerzeniem.',
      nipPL: 'Proszę o podanie prawidłowego numeru NIP.',
      phonePL: 'Proszę o podanie prawidłowego numeru telefonu',
      maxlength: a.validator.format('Proszę o podanie nie więcej niż {0} znaków.'),
      minlength: a.validator.format('Proszę o podanie przynajmniej {0} znaków.'),
      rangelength: a.validator.format('Proszę o podanie wartości o długości od {0} do {1} znaków.'),
      range: a.validator.format('Proszę o podanie wartości z przedziału od {0} do {1}.'),
      max: a.validator.format('Proszę o podanie wartości mniejszej bądź równej {0}.'),
      min: a.validator.format('Proszę o podanie wartości większej bądź równej {0}.'),
      pattern: a.validator.format('Pole zawiera niedozwolone znaki.'),
    }),
    a
  );
});
